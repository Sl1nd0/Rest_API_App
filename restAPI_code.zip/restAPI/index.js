var express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;
const routes = require('./src/routes/crmRoutes');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
let pp = require('./package.json');

//console.log(pp.name + " &&&&&&& ");

mongoose.connect('mongodb://localhost/mydb', {
useNewUrlParser: true
})

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

/*
//Define Schema 
const cat = mongoose.model('Cat', {name: String});

const Kitty = new cat({ "name": "Kitty2"});

Kitty.save().then((res)=>{
    console.log(res);
    console.log("Meow");
})
*/
//routes(app);

const BlogSchema = require('./src/models/crmModel');
const blogModel = mongoose.model('blog', BlogSchema);

app.post('/newBlog', (req, res)=> { //End Point to sent data 
                    // To The Database
    let blog = new blogModel(req.body);
    blog.save((err, blogModel) => {
        if (err) {
            res.send(err);
        }
        res.json(blog);
    })
});

let getAllBlogs = (req, res) => {
    blogModel.find({}, (err, blogs) => {
        if (err) {
            res.send(err);
        } else {
            res.json(blogs);
        }
    })
}

app.get('/getBlogs', getAllBlogs);

app.listen(PORT, () => {
    console.log('Server started on port ' + PORT);
});