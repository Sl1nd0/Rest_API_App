const toDate = require('normalize-date');
const moment = require('moment');

const date3 = toDate('2000-01-05T23:59:59', {noTime: true});
//let tt = '1344549600';
//var unixTimestamp = moment('2012-08-10', 'YYYY-MM-DD').unix();
//var unixTimestamp = moment('2012-08-10', 'YYYY-MM-DD');
var unixTimestamp = moment.unix('1344549600');
let newM = new Date('2012-08-10');
var unixTimestamp2 = moment.unix(newM);

console.log(unixTimestamp._i);

//console.log('\n\n\n' + newM.isValid());
 var datum = Date.parse('2012-08-10');
 
 console.log(datum);

//console.log(unixTimestamp2._i);

/****

let params = req.params.ToDo;
  //console.log(params);
  var timestamp = Date.parse(params);

if (isNaN(timestamp) == false) {
    var d = new Date(timestamp); //Resolve date to normal
    console.log(d); //Got Date
  } else if (isNaN(timestamp) == true) {
    var unixTimestamp = moment.unix(timestamp);
    console.log(timestamp);
    if (unixTimestamp.isValid()) {
        console.log('Valid');
    } else {
        console.log('inValid');
    }
  }
  
  
  
  *****/
  
  
  
  
  let date;
  let realDate = new Date(params);
  let unixDate = Date.parse(params);
  let myResult = {};
  //console.log(params + "    " + unixDate);
  
   if (realDate == "Invalid Date" || isNaN(unixDate) == false)
    {
       //{"unix": 1479663089000 ,"utc": "Sun, 20 Nov 2016 17:31:29 GMT"}
      myResult = {"error" : "Invalid Date" };  
      res.json(myResult);
    } else if (realDate != "Invalid Date" || isNaN(unixDate) == true) {
       realDate = new Date();
      unixDate = Date.parse(realDate);
    
      myResult.unix = unixDate;
      myResult.utc = realDate;
  
      res.send(myResult);
    }