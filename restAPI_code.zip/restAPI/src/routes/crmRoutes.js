const routes = (app) => {   
    app.route('/')
    .get((req, res) => {
        //res.send` Node listeninhg on port : ${PORT}`;
        res.send('This is a get Method');
    })
    
    
    .post((req, res) => {
        res.send('This is a post Method');
    })
    
    .put((req, res) => {
        res.send('This is a put Method');
    })
    
    .delete((req, res) => {
        res.send('This is a delete Method');
    });
    }

    module.exports = routes;